import java.io.*;

public class DeleteFiles {
    
    File file;
    FileWriter fw;

    public DeleteFiles(String folderi) throws IOException{
        file = new File(folderi);
        fw = new FileWriter("ubt.out");
    }

    public void fshij(String part) throws IOException{
        int total = 0;
        int kushti = 0;
        if(file.isDirectory()){
            for(File f: file.listFiles()){
                total++;
                if(f.isFile() && f.getName().contains(part)){
                    kushti++;
                    f.delete();
                }
            }
        }

        fw.write("Total: " + total + " dhe jane fshire: " + kushti);

        fw.close();
    }

    public static void main(String [] args){
        try {
            DeleteFiles kb = new DeleteFiles("ok/ubt");
            kb.fshij("part");
        } catch (Exception e) {
            e.printStackTrace();
        }  
    }


}
