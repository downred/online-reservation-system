package ok;
import java.io.*;

public class NumeroRreshtat{
    FileReader fr;
    FileWriter fw;
    BufferedReader br;

    public NumeroRreshtat(String input, String output) throws IOException{
        fr = new FileReader(input);
        br = new BufferedReader(fr);
        fw = new FileWriter(output);
    }

    public int numero(String txt) throws IOException{
        String rreshti;
        int count = 0;

        while((rreshti = br.readLine())!= null ){
            if(rreshti.startsWith(txt)){
                count++;
            }
        }
       
        return count;
    }

    public void numeroRreshtat(String txt) throws IOException{
        fw.write("Numri i rreshtave ne file qe fillojne me " + txt + " eshte " + numero(txt));
        br.close();
        fw.close();
    }

    public static void main(String [] args){
        try{
            NumeroRreshtat nr = new NumeroRreshtat("ubt.txt", "ubt.out");
            nr.numeroRreshtat("Exception");
        }catch(IOException e){
            e.printStackTrace();
        }
    }
}