import java.io.*;

public class ListoKiloBajtet {
    File file;
    FileWriter fw;
    public ListoKiloBajtet(String folderi) throws IOException{
         file = new File(folderi);
         fw = new FileWriter("ubt.out");
    }

    public void listoKB(String ext, long kb)throws IOException{
        if(file.isDirectory()){
            for(File f: file.listFiles()){
                if(f.getName().endsWith(ext) && (f.length()/1024) >= kb){
                    fw.write(f.getName() + " - " + f.length() + " KB");
                }
            }
        }
        fw.close();
    }



    public static void main(String [] args){
        try {
            ListoKiloBajtet kb = new ListoKiloBajtet("ok");
            kb.listoKB(".java", 1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
}
