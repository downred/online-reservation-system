import java.io.*;

public class CountFiles {
    File file;
    FileWriter fw;
    public CountFiles(String folderi) throws IOException{
         file = new File(folderi);
         fw = new FileWriter("file.out");
    }

    public int count(int size)throws IOException{
        int count = 0;
        if(file.isDirectory()){
            for(File f: file.listFiles()){
                if(f.isFile() && f.length() <= size){
                    count++;
                }
            }
        }
       

        return count;
    }

    public void write() throws IOException{
        fw.write("Total file ishin: " + file.listFiles().length);
        fw.write("Total file qe e plotesonin kushtin ishin: " + count(200));
        fw.close();
    }

    public static void main(String [] args){
        try {
            CountFiles cf = new CountFiles("ok/ubt");
            cf.write();
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
}
