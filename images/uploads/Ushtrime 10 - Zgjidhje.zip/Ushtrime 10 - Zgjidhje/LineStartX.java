import java.io.*;

public class LineStartX{
    FileReader fr;
    FileWriter fw;
    LineNumberReader br;

    public LineStartX(String input) throws IOException{
        fr = new FileReader(input);
        br = new LineNumberReader(fr);
        fw = new FileWriter("java.out");
    }

    public String evenXLine() throws IOException{
        String rreshti;
        String line = "";
        int nr_rreshtit = 0;
       
        while((rreshti = br.readLine())!= null ){
            br.setLineNumber(1);
            if(rreshti.startsWith("X") && rreshti.length() % 2 == 0 && rreshti.length() >= line.length()){
                line = rreshti;
                nr_rreshtit = br.getLineNumber();
            }
        }
       
        return line;
    }

    public void write() throws IOException{
        fw.write("Rreshti me i gjate me gjatesi cift qe fillon me X eshte: " + evenXLine());
        br.close();
        fw.close();
    }

    public static void main(String [] args){
        try{
            LineStartX lwx = new LineStartX("java.txt");
            lwx.write();
        }catch(IOException e){
            e.printStackTrace();
        }
    }
}

