import java.io.*;

public class LineWithoutA{
    FileReader fr;
    FileWriter fw;
    BufferedReader br;

    public LineWithoutA(String input) throws IOException{
        fr = new FileReader(input);
        br = new BufferedReader(fr);
        fw = new FileWriter("ubt.out");
    }

    public String longestNonALine() throws IOException{
        String rreshti;
        String line = "";

        while((rreshti = br.readLine())!= null ){
            if(!rreshti.toUpperCase().contains("A") && rreshti.length() >= line.length()  ){
                line = rreshti;
            }
        }
       
        return line;
    }

    public void shkruaj() throws IOException{
        fw.write("Rreshti i fundit me i gjate qe nuk permban shkronjen A eshte: " + longestNonALine());
        br.close();
        fw.close();
    }

    public static void main(String [] args){
        try{
            LineWithoutA lwa = new LineWithoutA("ubt.txt");
            lwa.shkruaj();
        }catch(IOException e){
            e.printStackTrace();
        }
    }
}
